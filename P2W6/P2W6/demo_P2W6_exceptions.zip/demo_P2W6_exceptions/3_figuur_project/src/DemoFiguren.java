public class DemoFiguren {
    public static void main(String[] args) {

    }
}
