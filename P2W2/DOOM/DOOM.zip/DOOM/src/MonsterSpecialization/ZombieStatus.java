package MonsterSpecialization;

/**
 * Vincent Verboven
 * 22/11/2022
 */
public enum ZombieStatus {
    ALIVE,DEATH
}
