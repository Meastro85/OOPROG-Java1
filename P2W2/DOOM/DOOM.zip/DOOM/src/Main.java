/**
 * Vincent Verboven
 * 22/11/2022
 */
public class Main {
    public static void main(String[] args) {
        Doom doom = new Doom();
        doom.menu();

    }
}
