package rekenen;

import rekenen.plugins.Plugin;

/**
 * PEER TUTORING
 * REKENMACHINE
 */
public class Rekenmachine {
    private final int MAX_AANTAL_PLUGINS = 10;
    private Plugin[] ingeladenPlugins;
    private int aantalPlugins;

    public Rekenmachine() {
        this.ingeladenPlugins = new Plugin[MAX_AANTAL_PLUGINS];
        aantalPlugins = 0;
    }

    public void installeer(Plugin teInstallerenPlugin) {
        //Opgave 2.1.a
    }

    public double bereken(String command, double x, double y) {
        //Opgave 2.1.b
        return 0;
    }

    @Override
    public String toString() {
        //Opgave 2.1c
        return "";
    }
}
