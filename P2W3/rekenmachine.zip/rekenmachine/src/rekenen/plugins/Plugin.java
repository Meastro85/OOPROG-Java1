package rekenen.plugins;

/**
 * PEER TUTORING
 * REKENMACHINE
 */
public interface Plugin {
    //Opgave 1.1
}